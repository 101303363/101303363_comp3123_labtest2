import React, {useState} from 'react';
import axios from 'axios'

import './index.css';


function App() {
  const [data,setData]= useState({})
  const [location,setLocation] =useState('')
  

  const url =`https://api.openweathermap.org/data/2.5/weather?q=${location}&units=imperial&appid=da8c1040837628e95a1ddbad0d86a369`

  

    const searchLocation = (event)=>{
      if(event.key === 'Enter'){
      axios.get(url).then((response)=>{
        setData(response.data)
        console.log(response.data)

      })
      setLocation('')
    }
  }
 
  return (
    <div style={{textAlign:"center",backgroundColor:'red' }}>
    
    <div>
      
      <div style={{textAlign:"center",padding: "75px"}}>
        <input value={location} onChange={event=>setLocation(event.target.value)} onKeyPress={searchLocation}  placeholder="please enter the city" type="text"/>
      </div>

      <div  style={{textAlign:"center"}}>
      <div>
        <div>
          {data.main? <h1>Location: {data.name} </h1> : null}

        </div>

        <div>
          {data.main? <h1>Temperature {data.main.temp} ℉</h1> : null}
        </div>

        <div>
        {data.main? <h1>Weather Situation :{data.weather[0].main}</h1> : null}
        </div>

        <div>
          {data.main ? <h1>Humidity:{data.main.humidity}%</h1> : null}
        </div>

        <div>
          {/* <p>Wind Speed</p> */}
          {data.wind ? <h1>{data.wind.speed}MPH</h1> : null}
        </div>
        
      </div>
    
      </div>
  
      
    </div>
    </div>

    
  );
}

export default App;
